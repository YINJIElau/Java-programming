import java.util.ArrayList;

public class Question4 {
	
	public static String getMostCommon(Object [] o) {

	}
	
	public static ArrayList<Pair> findPairs(int [] array, int product) {

	}
	
	public static int[][] reverseArray (int [][] array, boolean b1, boolean b2) {

	}
}

class Pair {
	
	private int a, b;
	
	public Pair(int a, int b) {
		this.a = a;
		this.b = b;
	}
	
	public boolean equals(Object o) {
		if (o instanceof Pair) {
			return (((Pair)o).a == a && ((Pair)o).b == b) || (((Pair)o).a == b && ((Pair)o).b == a);
		} else {
			return false;
		}
	}
	
	public String toString() {
		return "(" + a + "," + b + ")";
	}
}
