import org.junit.jupiter.api.Test;

import java.lang.reflect.Method;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class Q1Tests {

    @Test
    public void testComputer() {
        Method[] methods = Computer.class.getMethods();

        int count = 0;

        for (Method m : methods) {
            if (m.getName().trim().equalsIgnoreCase("getRAM")) {
                if (m.getReturnType().getSimpleName().equals("int")) {
                    count++;
                }
            } else if (m.getName().trim().equalsIgnoreCase("getHDSpace")) {
                if (m.getReturnType().getSimpleName().equals("int")) {
                    count++;
                }
            } else if (m.getName().trim().equalsIgnoreCase("getDevices")) {
                if (m.getReturnType().getSimpleName().equals("ArrayList")) {
                    count++;
                }
            } else if (m.getName().trim().equalsIgnoreCase("getCPUs")) {
                if (m.getReturnType().getSimpleName().equals("ArrayList")) {
                    count++;
                }
            }

        }

        System.out.println(count);
        System.out.println(Computer.class.isInterface());

        assertEquals(4, count);
        assertTrue(Computer.class.isInterface());
    }

    @Test
    public void testCPU() {
        CPU c1 = new CPU("AMD", 4, 2.6);
        System.out.println(c1.getType() + " " + c1.getClockSpeed() + " " + c1.getNoCores());

        CPU c2 = new CPU("Intel", 8, 3.6);
        System.out.println(c2.getType() + " " + c2.getClockSpeed() + " " + c2.getNoCores());

        assertEquals("AMD 2.6 4", c1.getType() + " " + c1.getClockSpeed() + " " + c1.getNoCores());
        assertEquals("Intel 3.6 8", c2.getType() + " " + c2.getClockSpeed() + " " + c2.getNoCores());
    }

    @Test
    public void testGPU() {
        CPU c = new GPU("Nvidia", 4, 2.6, 8);
        System.out.println(c.getType() + " " + c.getClockSpeed() + " " + c.getNoCores());

        GPU g = (GPU)c;
        System.out.println(g.getMemory());

        assertEquals("Nvidia 2.6 4", c.getType() + " " + c.getClockSpeed() + " " + c.getNoCores());
        assertEquals(8, g.getMemory());
    }

    @Test
    public void testToString() {
        CPU c1 = new CPU("AMD", 4, 2.6);
        System.out.println(c1);

        CPU c2 = new CPU("Intel", 8, 3.6);
        System.out.println(c2);

        CPU c3 = new GPU("nVidia", 4, 2.6, 8);
        System.out.println(c3);

        GPU g = new GPU("Tesla", 100, 3.6, 64);
        System.out.println(g);

        assertEquals("CPU: AMD, clock speed 2.6, has 4 cores", c1.toString());
        assertEquals("CPU: Intel, clock speed 3.6, has 8 cores", c2.toString());
        assertEquals("GPU: nVidia, clock speed 2.6, has 4 cores and 8GB memory", c3.toString());
        assertEquals("GPU: Tesla, clock speed 3.6, has 100 cores and 64GB memory", g.toString());
    }

    @Test
    public void testWorkstationOne() {
        CPU c = new CPU("Intel", 8, 2.6);
        GPU g = new GPU("nVidia", 4, 2.6, 16);
        ArrayList<CPU> cpus = new ArrayList<CPU>();
        cpus.add(c);
        cpus.add(c);
        cpus.add(g);
        cpus.add(g);
        ArrayList<String> devices = new ArrayList<String>();
        devices.add("keyboard");
        devices.add("mouse");
        Computer comp = new Workstation(16, 1, cpus, devices);

        System.out.println(comp.getRAM());
        System.out.println(comp.getHDSpace());
        System.out.println(comp.getDevices());
        System.out.println(comp.getCPUs());

        assertEquals(16, comp.getRAM());
        assertEquals(1, comp.getHDSpace());
        assertEquals("[keyboard, mouse]", comp.getDevices().toString());
        assertEquals("[CPU: Intel, clock speed 2.6, has 8 cores, CPU: Intel, clock speed 2.6, has 8 cores, GPU: nVidia, clock speed 2.6, has 4 cores and 16GB memory, GPU: nVidia, clock speed 2.6, has 4 cores and 16GB memory]", comp.getCPUs().toString());
    }

    @Test
    public void testWorkstationTwo() {
        CPU c = new CPU("AMD", 4, 2.6);
        ArrayList<CPU> cpus = new ArrayList<CPU>();
        cpus.add(c);
        cpus.add(c);
        ArrayList<String> devices = new ArrayList<String>();
        devices.add("keyboard");
        devices.add("mouse");
        Workstation comp = new Workstation(16, 1, cpus, devices);
        System.out.println(comp);

        assertEquals("Workstation: 16GB RAM, 1TB HD, [CPU: AMD, clock speed 2.6, has 4 cores, CPU: AMD, clock speed 2.6, has 4 cores], [keyboard, mouse]", comp.toString());
    }

    @Test
    public void testWorkstationThree() {
        CPU c = new CPU("Intel", 8, 2.6);
        GPU g = new GPU("nVidia", 4, 2.6, 16);
        ArrayList<CPU> cpus = new ArrayList<CPU>();
        cpus.add(c);
        cpus.add(c);
        cpus.add(g);
        cpus.add(g);
        ArrayList<String> devices = new ArrayList<String>();
        devices.add("keyboard");
        devices.add("mouse");
        Workstation comp = new Workstation(16, 1, cpus, devices);
        System.out.println(comp);

        assertEquals("Workstation: 16GB RAM, 1TB HD, [CPU: Intel, clock speed 2.6, has 8 cores, CPU: Intel, clock speed 2.6, has 8 cores, GPU: nVidia, clock speed 2.6, has 4 cores and 16GB memory, GPU: nVidia, clock speed 2.6, has 4 cores and 16GB memory], [keyboard, mouse]", comp.toString());

    }

    @Test
    public void testLaptop() {
        CPU c = new CPU("AMD", 4, 2.6);
        ArrayList<CPU> cpus = new ArrayList<CPU>();
        cpus.add(c);
        cpus.add(c);
        ArrayList<String> devices = new ArrayList<String>();
        devices.add("keyboard");
        devices.add("mouse");
        devices.add("Screen");
        Computer comp = new Laptop(16, 1, cpus, devices);
        System.out.println(comp);

        assertEquals("Laptop: 16GB RAM, 1TB HD, [CPU: AMD, clock speed 2.6, has 4 cores, CPU: AMD, clock speed 2.6, has 4 cores], [keyboard, mouse, Screen]", comp.toString());
    }

    @Test
    public void testLaptopErrors() {
        CPU c = new CPU("AMD", 4, 2.6);
        ArrayList<CPU> cpus = new ArrayList<CPU>();
        cpus.add(c);
        cpus.add(c);
        ArrayList<String> devices = new ArrayList<String>();
        devices.add("keyboard");
        devices.add("mouse");

        Laptop comp;

        try { comp = new Laptop(16, 1, cpus, devices); System.out.println("fail"); fail();}
        catch (IllegalArgumentException ex) {System.out.println("pass"); }
        catch (Exception ex) {System.out.println("fail"); fail();}

        c = new CPU("AMD", 4, 2.6);
        cpus = new ArrayList<CPU>();
        cpus.add(c);
        cpus.add(c);
        cpus.add(c);
        devices = new ArrayList<String>();
        devices.add("keyboard");
        devices.add("mouse");
        devices.add("Screen");
        try { comp = new Laptop(16, 1, cpus, devices); System.out.println("fail"); fail();}
        catch (IllegalArgumentException ex) {System.out.println("pass"); }
        catch (Exception ex) {System.out.println("fail"); fail();}

        c = new CPU("AMD", 4, 2.6);
        GPU g = new GPU("nVidia", 4, 2.6, 16);
        cpus = new ArrayList<CPU>();
        cpus.add(c);
        cpus.add(c);
        cpus.add(g);
        cpus.add(g);
        devices = new ArrayList<String>();
        devices.add("keyboard");
        devices.add("mouse");
        devices.add("Screen");
        try { comp = new Laptop(16, 1, cpus, devices); System.out.println("fail"); fail();}
        catch (IllegalArgumentException ex) {System.out.println("pass"); }
        catch (Exception ex) {System.out.println("fail"); fail();}
    }

    @Test
    public void testFactory() {
        CPU c = new CPU("AMD", 4, 2.6);
        ArrayList<CPU> cpus = new ArrayList<CPU>();
        cpus.add(c);
        cpus.add(c);
        ArrayList<String> devices = new ArrayList<String>();
        devices.add("keyboard");
        devices.add("mouse");
        devices.add("Screen");
        Laptop laptop = new Laptop(16, 1, cpus, devices);

        c = new CPU("Intel", 8, 2.6);
        GPU g = new GPU("nVidia", 4, 2.6, 16);
        cpus = new ArrayList<CPU>();
        cpus.add(c);
        cpus.add(c);
        cpus.add(g);
        cpus.add(g);
        devices = new ArrayList<String>();
        devices.add("keyboard");
        devices.add("mouse");
        Workstation comp = new Workstation(16, 1, cpus, devices);

        ArrayList<Workstation> a1 = Workstation.produceWorkstations(laptop, 5);

        for (Workstation w : a1) {
            System.out.println(w);
            System.out.println(laptop == w);
        }

        ArrayList<Workstation> a2 = Workstation.produceWorkstations(comp, 10);


        for (Workstation w : a2) {
            System.out.println(w);
            System.out.println(comp == w);
        }

        assertEquals(5, a1.size());
        assertEquals(10, a2.size());

        for (Workstation w : a1) {
            assertEquals(laptop, w);
            assertFalse(laptop == w);
        }

        for (Workstation w : a2) {
            assertEquals(comp, w);
            assertFalse(comp == w);
        }

    }

}