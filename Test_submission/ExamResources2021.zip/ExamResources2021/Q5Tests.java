import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class Q5Tests {
    //change these to where you saved the files
    String fileName = "./src/adult.txt";
    String fileNameError = "./src/adult-error.txt";

    @Test
    public void testPartA() {
        String s = "Bachelors,Married,CS,Male,<=50K";
        Adult a = new Adult(s);

        assertEquals("Bachelors", a.getEducation());
        assertEquals("Married", a.getStatus());
        assertEquals("CS", a.getDegree());
        assertEquals("Male", a.getGender());
        assertFalse(a.getSalary());
    }

    @Test
    public void testPartB() {
        try {
            ArrayList<Adult> a = Adult.read(fileName);

            Adult a1 = a.get(0);
            assertEquals("Bachelors", a1.getEducation());
            assertEquals("Married", a1.getStatus());
            assertEquals("CS", a1.getDegree());
            assertEquals("Male", a1.getGender());
            assertFalse(a1.getSalary());

            a1 = a.get(1);
            assertEquals("Bachelors", a1.getEducation());
            assertEquals("Married", a1.getStatus());
            assertEquals("Econ", a1.getDegree());
            assertEquals("Male", a1.getGender());
            assertFalse(a1.getSalary());

            assertEquals(21, a.size());

        } catch (Exception ex) {
            ex.printStackTrace();
            fail("An error occurred");
        }
    }

    @Test
    public void testPartC() {
        try {
            ArrayList<Adult> a = Adult.read(fileNameError);

            Adult a1 = a.get(0);
            assertEquals("Bachelors", a1.getEducation());
            assertEquals("Married", a1.getStatus());
            assertEquals("CS", a1.getDegree());
            assertEquals("Male", a1.getGender());
            assertFalse(a1.getSalary());

            a1 = a.get(1);
            assertEquals("Bachelors", a1.getEducation());
            assertEquals("Married", a1.getStatus());
            assertEquals("Econ", a1.getDegree());
            assertEquals("Male", a1.getGender());
            assertFalse(a1.getSalary());

            assertEquals(12, a.size());

        } catch (Exception ex) {
            ex.printStackTrace();
            fail("An error occurred");
        }
    }
}