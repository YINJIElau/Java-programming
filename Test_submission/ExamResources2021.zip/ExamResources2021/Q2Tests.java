import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Q2Tests {

    @Test
    public void testTeam() {
        Team rovers = new Team("Rovers", "Dublin");
        System.out.println(rovers);
        Team city = new Team("City", "Dublin");
        city.addDraw();
        System.out.println(city);
        Team united = new Team("United", "Dublin");
        united.addWin();
        System.out.println(united);
        System.out.println(united.getName() + " " + united.getLocation() + " " + united.getPoints());

        assertEquals("Rovers from Dublin currently have 0 points.", rovers.toString());
        assertEquals("City from Dublin currently have 1 point.", city.toString());
        assertEquals("United from Dublin currently have 3 points.", united.toString());
        assertEquals("United Dublin 3", united.getName() + " " + united.getLocation() + " " + united.getPoints());
    }

    @Test
    public void testScore() {
        Score s1 = new Score(1,1);
        System.out.println(s1.getHomeScore());
        System.out.println(s1.getAwayScore());
        Score s2 = new Score(2, 1);
        System.out.println(s2.getHomeScore());
        System.out.println(s2.getAwayScore());
        Score s3 = new Score(2,4);
        System.out.println(s3.getHomeScore());
        System.out.println(s3.getAwayScore());

        assertEquals(1, s1.getHomeScore());
        assertEquals(1, s1.getAwayScore());
        assertEquals(2, s2.getHomeScore());
        assertEquals(1, s2.getAwayScore());
        assertEquals(2, s3.getHomeScore());
        assertEquals(4, s3.getAwayScore());
    }

    @Test
    public void testGame() {
        Team t1 = new Team("Rovers", "Bray");
        Team t2 = new Team("City", "Dublin");
        Team t3 = new Team("United", "Belfield");
        Game g1 = new Game(t1, t2, new Score(2,1));
        System.out.println(g1);
        Game g2 = new Game(t3, t2, new Score(1,2));
        System.out.println(g2);
        Game g3 = new Game(t1, t3, new Score(1,1));
        System.out.println(g3);

        assertEquals("Rovers 2 - City 1; Result Rovers Won",g1.toString());
        assertEquals("United 1 - City 2; Result City Won",g2.toString());
        assertEquals("Rovers 1 - United 1; Result Draw",g3.toString());
    }



    @Test
    public void testLeagueOne() {
        League l = new League();
        Team t1 = new Team("Rovers", "Bray");
        Team t2 = new Team("City", "Dublin");
        Team t3 = new Team("United", "Belfield");
        l.addTeam(t1);
        l.addTeam(t2);
        l.addTeam(t3);
        System.out.println(l);

        String outcome = "Rovers from Bray currently have 0 points.\n" +
                "City from Dublin currently have 0 points.\n" +
                "United from Belfield currently have 0 points.";

        assertEquals(outcome, l.toString().trim());
    }

    @Test
    public void testLeagueTwo() {
        League l = new League();
        Team t1 = new Team("Rovers", "Bray");
        Team t2 = new Team("City", "Dublin");
        Team t3 = new Team("United", "Belfield");
        l.addTeam(t1);
        l.addTeam(t2);
        l.addTeam(t3);
        l.addGame(new Game(t1, t2, new Score(2,1)));
        l.addGame(new Game(t1, t3, new Score(2,2)));
        l.addGame(new Game(t2, t3, new Score(3,1)));
        l.addGame(new Game(t2, t1, new Score(0,4)));
        l.addGame(new Game(t3, t2, new Score(2,5)));
        l.addGame(new Game(t3, t1, new Score(2,1)));
        System.out.println(l);

        String outcome = "Rovers from Bray currently have 7 points.\n" +
                "City from Dublin currently have 6 points.\n" +
                "United from Belfield currently have 4 points.";

        assertEquals(outcome, l.toString().trim());
    }

    @Test
    public void testLeagueOrdered() {
        League l = new League();
        Team t1 = new Team("Rovers", "Bray");
        Team t2 = new Team("City", "Dublin");
        Team t3 = new Team("United", "Belfield");
        l.addTeam(t1);
        l.addTeam(t2);
        l.addTeam(t3);
        l.addGame(new Game(t1, t2, new Score(2,1)));
        l.addGame(new Game(t1, t3, new Score(2,2)));
        l.addGame(new Game(t2, t3, new Score(3,1)));
        l.addGame(new Game(t2, t1, new Score(0,4)));
        l.addGame(new Game(t3, t2, new Score(2,1)));
        l.addGame(new Game(t3, t1, new Score(2,1)));

        l.addGame(new Game(t1, t2, new Score(0,5)));
        l.addGame(new Game(t1, t3, new Score(2,2)));
        l.addGame(new Game(t2, t3, new Score(2,4)));
        l.addGame(new Game(t2, t1, new Score(0,4)));
        l.addGame(new Game(t3, t2, new Score(2,0)));
        l.addGame(new Game(t3, t1, new Score(2,1)));

        System.out.println(l);
        System.out.println(l.orderedToString());

        String outcome = "United from Belfield currently have 17 points.\n" +
                "Rovers from Bray currently have 11 points.\n" +
                "City from Dublin currently have 6 points.";

        assertEquals(outcome, l.orderedToString().trim());
    }

    @Test
    public void testLeagueOrderedWithTie() {
        League l = new League();
        Team t1 = new Team("Rovers", "Bray");
        Team t2 = new Team("City", "Dublin");
        Team t3 = new Team("United", "Belfield");
        l.addTeam(t1);
        l.addTeam(t2);
        l.addTeam(t3);

        l.addGame(new Game(t1, t2, new Score(2,0)));
        l.addGame(new Game(t1, t3, new Score(2,2)));
        l.addGame(new Game(t2, t3, new Score(1,5)));

        System.out.println(l);
        System.out.println(l.orderedToString());

        String outcome = "United from Belfield currently have 4 points.\n" +
                "Rovers from Bray currently have 4 points.\n" +
                "City from Dublin currently have 0 points.";

        assertEquals(outcome, l.orderedToString().trim());
    }


}