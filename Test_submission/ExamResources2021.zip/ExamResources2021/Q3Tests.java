import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class Q3Tests {

    @Test
    void testPartA() {
        try {
            Draw.class.getDeclaredMethod("triangle", int.class, int.class, char.class, char.class);
        } catch (NoSuchMethodException ex) {
            fail("triangle method signature incorrect");
        }

        try {
            Draw.class.getDeclaredMethod("crosses", int.class, int.class, char.class, char.class, boolean.class);
        } catch (NoSuchMethodException ex) {
            fail("crosses method signature incorrect");
        }

        try {
            Draw.triangle(-1, -1, 'x', 'o');
            fail("Boxes: invalid input");
        } catch (Exception ex) {}

        try {
            Draw.crosses(-1, -1, 'x', 'o', false);
            fail("Stripes: invalid input");
        } catch (Exception ex) {}
    }

    @Test
    void testPartB() {
        //example 1
        String s = Draw.triangle(6,13,'x', '.');
        String answer = "......x......\n" +
                ".....xxx.....\n" +
                "....xxxxx....\n" +
                "...xxxxxxx...\n" +
                "..xxxxxxxxx..\n" +
                ".xxxxxxxxxxx.";

        assertEquals(answer, s);

        //example 2
        s = Draw.triangle(7,19,'o', '-');
        answer = "---------o---------\n" +
                "--------ooo--------\n" +
                "-------ooooo-------\n" +
                "------ooooooo------\n" +
                "-----ooooooooo-----\n" +
                "----ooooooooooo----\n" +
                "---ooooooooooooo---";

        assertEquals(answer, s);
    }

    @Test
    void testPartC() {
        String s = Draw.crosses(13, 13, 'x', '.', true);
        String answer = "xxxxxxxxxxxxx\n" +
                "x..x..x..x..x\n" +
                "x..x..x..x..x\n" +
                "xxxxxxxxxxxxx\n" +
                "x..x..x..x..x\n" +
                "x..x..x..x..x\n" +
                "xxxxxxxxxxxxx\n" +
                "x..x..x..x..x\n" +
                "x..x..x..x..x\n" +
                "xxxxxxxxxxxxx\n" +
                "x..x..x..x..x\n" +
                "x..x..x..x..x\n" +
                "xxxxxxxxxxxxx";

        assertEquals(answer, s);

        s = Draw.crosses(12, 12, 'x', '.', false);
        answer = "..x......x..\n" +
                "...x....x...\n" +
                "x...x..x...x\n" +
                ".x...xx...x.\n" +
                "..x..xx..x..\n" +
                "...xx..xx...\n" +
                "...xx..xx...\n" +
                "..x..xx..x..\n" +
                ".x...xx...x.\n" +
                "x...x..x...x\n" +
                "...x....x...\n" +
                "..x......x..";

        assertEquals(answer, s);
    }

}