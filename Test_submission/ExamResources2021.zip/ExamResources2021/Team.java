import java.util.ArrayList;

class Score {
    public Score(int home, int away) {
        
    }
}

class Team {
    public Team(String name, String location) {
        
    }
    
    public void addWin() {
        
    }
    
    public void addDraw() {
        
    }
    
    public String toString() {
        
    }
}

class Game {
    public Game(Team home, Team away, Score score) {
        
    }
    
    public String toString() {
        
    }
}

class League {
    public League() {
        
    }
}
