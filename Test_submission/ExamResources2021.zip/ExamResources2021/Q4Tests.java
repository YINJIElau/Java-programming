import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

public class Q4Tests {
    @Test
    public void testPartA() {
        //example 1
        Object [] o1 = {1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 1, 1};
        assertEquals("1", Question4.getMostCommon(o1));

        //example 2
        Object [] o2 = {"1", "1", 1, 1, 2, 2, 2, "a", "Exam"};
        assertEquals("1", Question4.getMostCommon(o2));

        //example 3
        Object [] o3 = {1, 1, 1, 2, 2, 2, 3, 3, 4, 5, 6};
        assertEquals("it's a tie", Question4.getMostCommon(o3));
    }

    @Test
    public void testPartB() {
        //example 1
        int [] i1 = {1, 1, 1, 2, 2, 1, 1, 1};
        ArrayList<Pair> a1 = Question4.findPairs(i1, 4);
        ArrayList<Pair> answer = new ArrayList<Pair>();
        answer.add(new Pair(2, 2));
        assertEquals(answer, a1);

        //example 2
        int [] i2 = {1, 2, 3, 4, 5, 6, 7, 8};
        ArrayList<Pair> a2 = Question4.findPairs(i2, 12);
        answer = new ArrayList<Pair>();
        answer.add(new Pair(2, 6));
        answer.add(new Pair(3, 4));
        assertEquals(answer, a2);

        //example 3
        int [] i3 = {1, 1, 1, 1, 1, 1};
        ArrayList<Pair> a3 = Question4.findPairs(i3, 3);
        assertEquals(0, a3.size());
    }

    @Test
    public void testPartC1() {
        int [][] array1 = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int [][] array2 = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}};

        int [][] array_a1 = Question4.reverseArray(array1, true, false);
        int [][] array_a2 = Question4.reverseArray(array2, true, false);
        assertEquals("[[7, 8, 9], [4, 5, 6], [1, 2, 3]]", java.util.Arrays.deepToString(array_a1));
        assertEquals("[[9, 10, 11, 12], [5, 6, 7, 8], [1, 2, 3, 4]]", java.util.Arrays.deepToString(array_a2));

    }

    @Test
    public void testPartC2() {
        int [][] array1 = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int [][] array2 = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}};

        int [][] array_a1 = Question4.reverseArray(array1, false, true);
        int [][] array_a2 = Question4.reverseArray(array2, false, true);
        assertEquals("[[3, 2, 1], [6, 5, 4], [9, 8, 7]]", java.util.Arrays.deepToString(array_a1));
        assertEquals("[[4, 3, 2, 1], [8, 7, 6, 5], [12, 11, 10, 9]]", java.util.Arrays.deepToString(array_a2));

    }

    @Test
    public void testPartC3() {
        int [][] array1 = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int [][] array2 = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}};

        int [][] array_a1 = Question4.reverseArray(array1, true, true);
        int [][] array_a2 = Question4.reverseArray(array2, true, true);
        assertEquals("[[9, 8, 7], [6, 5, 4], [3, 2, 1]]", java.util.Arrays.deepToString(array_a1));
        assertEquals("[[12, 11, 10, 9], [8, 7, 6, 5], [4, 3, 2, 1]]", java.util.Arrays.deepToString(array_a2));

    }

    @Test
    public void testPartC4() {
        int [][] array1 = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int [][] array2 = {{1, 2, 3, 4}, {5, 6, 7, 8}, {9, 10, 11, 12}};

        int [][] array_a1 = Question4.reverseArray(array1, false, false);
        int [][] array_a2 = Question4.reverseArray(array2, false, false);
        assertEquals("[[1, 2, 3], [4, 5, 6], [7, 8, 9]]", java.util.Arrays.deepToString(array_a1));
        assertEquals("[[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12]]", java.util.Arrays.deepToString(array_a2));

    }
}