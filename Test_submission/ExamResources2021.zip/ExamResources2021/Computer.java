import java.util.ArrayList;

interface Computer {
    //add methods
}

class CPU {
    //complete me
}

class GPU {
    //complete me
}

class Workstation {
    //complete me
}

class Laptop {
    //complete me
}

@FunctionalInterface
interface Factory {
    ArrayList<Workstation> build(Workstation w, int times);
}
